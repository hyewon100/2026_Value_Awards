/*
 * app.js — 화면 동작을 담당합니다.
 *  - 부문 카드/월 선택 목록 만들기
 *  - 개인/단체 전환, 구성원 추가/삭제
 *  - 입력값 모으기 → 검증(validation.js) → 확인 화면 → 제출(submission-service.js)
 *
 * 보안 메모: 사용자가 입력한 글은 항상 textContent 로만 화면에 넣습니다.
 * (innerHTML 을 쓰면 입력값 속 HTML/스크립트가 실행될 위험이 있습니다.)
 */
(function (App) {
  'use strict';

  var cfg = App.config;

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function byId(id) { return document.getElementById(id); }

  var els = {
    formView: byId('form-view'),
    reviewView: byId('review-view'),
    resultView: byId('result-view'),
    form: byId('nomination-form'),
    categoryOptions: byId('category-options'),
    individual: byId('individual-target'),
    group: byId('group-target'),
    memberList: byId('member-list'),
    memberTpl: byId('member-row-template'),
    memberCount: byId('member-count'),
    addMember: byId('add-member'),
    periodStart: byId('period-start'),
    periodEnd: byId('period-end'),
    errorSummary: byId('error-summary'),
    errorList: byId('error-list'),
    reviewContent: byId('review-content'),
    submitBtn: byId('submit-btn'),
    submitModeNote: byId('submit-mode-note')
  };

  var memberSeq = 0;      // 구성원 줄마다 고유 번호를 붙이기 위한 카운터
  var attempted = false;  // 한 번이라도 [작성 내용 확인]을 눌렀는가
  var isDirty = false;    // 입력한 내용이 있는가 (페이지 이탈 경고용)
  var currentState = null;
  var submitting = false;

  /* =========================================================
   * 1. 초기 화면 구성
   * ========================================================= */
  function renderCategories() {
    cfg.categories.forEach(function (c) {
      var label = document.createElement('label');
      label.className = 'option-card';

      var input = document.createElement('input');
      input.type = 'radio';
      input.name = 'category';  // 같은 name 의 radio 는 1개만 선택됩니다.
      input.value = c.value;

      var body = document.createElement('span');
      body.className = 'option-body';
      var title = document.createElement('span');
      title.className = 'option-title';
      title.textContent = c.label;
      var summary = document.createElement('span');
      summary.className = 'option-summary';
      summary.textContent = c.summary;
      var example = document.createElement('span');
      example.className = 'option-example';
      example.textContent = '예) ' + c.example;

      body.appendChild(title);
      body.appendChild(summary);
      body.appendChild(example);
      label.appendChild(input);
      label.appendChild(body);
      els.categoryOptions.appendChild(label);
    });
  }

  function renderMonths(select, placeholder) {
    var opt = document.createElement('option');
    opt.value = '';
    opt.textContent = placeholder;
    select.appendChild(opt);
    for (var m = 1; m <= 12; m++) {
      var o = document.createElement('option');
      o.value = String(m);
      o.textContent = m + '월';
      select.appendChild(o);
    }
  }

  function applyLimits(root) {
    $$('[data-limit]', root).forEach(function (el) {
      var n = cfg.limits[el.getAttribute('data-limit')];
      if (n) el.maxLength = n;
    });
  }

  function formatDate(d) {
    return d.getFullYear() + '. ' + (d.getMonth() + 1) + '. ' + d.getDate() + '.';
  }

  function renderDeadline() {
    byId('deadline-label').textContent = cfg.deadlineLabel;
    if (Date.now() > new Date(cfg.deadline).getTime()) {
      var n = byId('deadline-notice');
      n.textContent = '접수 기한이 지났습니다. (모의 모드에서는 테스트 작성은 가능합니다)';
      n.hidden = false;
    }
  }

  /* =========================================================
   * 2. 개인 / 단체 전환과 구성원 추가·삭제
   * ========================================================= */
  function getType() {
    var r = $('input[name="nominationType"]:checked', els.form);
    return r ? r.value : '';
  }

  function updateTypeUI() {
    var isGroup = getType() === 'group';
    els.individual.hidden = isGroup;
    els.group.hidden = !isGroup;
    // 단체로 처음 바꾸면 최소 인원(2명)만큼 빈 줄을 만들어 둡니다.
    if (isGroup) {
      while (els.memberList.children.length < cfg.members.min) addMember();
    }
    refreshMembers();
  }

  function addMember() {
    if (els.memberList.children.length >= cfg.members.max) return null;
    var uid = ++memberSeq;
    var node = els.memberTpl.content.firstElementChild.cloneNode(true);
    node.setAttribute('data-uid', String(uid));

    $$('[data-field]', node).forEach(function (input) {
      var f = input.getAttribute('data-field');
      input.id = 'member-' + uid + '-' + f;
    });
    $$('[data-for]', node).forEach(function (label) {
      label.setAttribute('for', 'member-' + uid + '-' + label.getAttribute('data-for'));
    });
    $$('[data-error]', node).forEach(function (p) {
      p.id = 'member-' + uid + '-' + p.getAttribute('data-error') + '-error';
    });
    applyLimits(node);
    els.memberList.appendChild(node);
    refreshMembers();
    return node;
  }

  function removeMember(row) {
    if (els.memberList.children.length <= cfg.members.min) return;
    row.parentNode.removeChild(row);
    refreshMembers();
    isDirty = true;
    if (attempted) runValidation(false);
  }

  function refreshMembers() {
    var rows = $$('.member-row', els.memberList);
    rows.forEach(function (row, i) {
      $('.member-no', row).textContent = '구성원 ' + (i + 1);
      var btn = $('[data-action="remove"]', row);
      btn.disabled = rows.length <= cfg.members.min;
      btn.setAttribute('aria-label', '구성원 ' + (i + 1) + ' 삭제');
    });
    els.memberCount.textContent = '현재 ' + rows.length + '명';
    els.addMember.disabled = rows.length >= cfg.members.max;
  }

  /* =========================================================
   * 3. 입력값 모으기 (화면 → 데이터)
   * ========================================================= */
  function val(id) { return byId(id).value; }

  function collectState() {
    var cat = $('input[name="category"]:checked', els.form);
    return {
      category: cat ? cat.value : '',
      nominationType: getType(),
      target: { name: val('target-name'), org: val('target-org'), rank: val('target-rank') },
      members: $$('.member-row', els.memberList).map(function (row) {
        var uid = row.getAttribute('data-uid');
        var get = function (f) { return $('[data-field="' + f + '"]', row).value; };
        return { uid: uid, name: get('name'), org: get('org'), rank: get('rank'), role: get('role') };
      }),
      nominator: {
        name: val('nominator-name'),
        org: val('nominator-org'),
        isSelf: byId('nominator-self').checked
      },
      winningRule: { number: val('rule-number'), text: val('rule-text') },
      period: {
        startMonth: els.periodStart.value ? Number(els.periodStart.value) : null,
        endMonth: els.periodEnd.value ? Number(els.periodEnd.value) : null
      },
      content: {
        action: val('content-action'),
        change: val('content-change'),
        evidence: val('content-evidence')
      },
      factConfirmed: byId('fact-confirm').checked
    };
  }

  /* =========================================================
   * 4. 검증 결과를 화면에 표시
   * ========================================================= */
  function clearErrors() {
    $$('.field-error').forEach(function (p) { p.hidden = true; p.textContent = ''; });
    $$('[aria-invalid="true"]').forEach(function (el) {
      el.removeAttribute('aria-invalid');
      el.removeAttribute('aria-describedby');
    });
    $$('.is-invalid').forEach(function (el) { el.classList.remove('is-invalid'); });
  }

  function showErrors(errors) {
    clearErrors();
    errors.forEach(function (err) {
      var target = byId(err.field);
      var msg = byId(err.field + '-error');
      if (msg) { msg.textContent = err.message; msg.hidden = false; }
      if (!target) return;
      if (target.matches('input, select, textarea')) {
        target.setAttribute('aria-invalid', 'true');
        if (msg) target.setAttribute('aria-describedby', msg.id);
      } else {
        target.classList.add('is-invalid');
      }
    });
  }

  function renderSummary(errors) {
    els.errorList.textContent = '';
    if (!errors.length) { els.errorSummary.hidden = true; return; }
    errors.forEach(function (err) {
      var li = document.createElement('li');
      var a = document.createElement('a');
      a.href = '#' + err.field;
      a.textContent = err.message;
      a.addEventListener('click', function (e) {
        e.preventDefault();
        focusField(err.field);
      });
      li.appendChild(a);
      els.errorList.appendChild(li);
    });
    els.errorSummary.hidden = false;
  }

  function focusField(id) {
    var el = byId(id);
    if (!el) return;
    var focusable = el.matches('input, select, textarea') ? el : $('input, select, textarea', el);
    (focusable || el).focus();
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function runValidation(withSummary) {
    var state = collectState();
    var errors = App.validate(state);
    showErrors(errors);
    if (withSummary) {
      renderSummary(errors);
    } else if (!errors.length) {
      els.errorSummary.hidden = true;
    } else if (!els.errorSummary.hidden) {
      renderSummary(errors); // 요약 상자가 열려 있으면 내용만 최신으로
    }
    return { state: state, errors: errors };
  }

  /* =========================================================
   * 5. 화면 전환 (작성 → 확인 → 결과)
   * ========================================================= */
  function showView(view) {
    els.formView.hidden = view !== 'form';
    els.reviewView.hidden = view !== 'review';
    els.resultView.hidden = view !== 'result';
    window.scrollTo(0, 0);
  }

  function addRow(dl, label, value) {
    var wrap = document.createElement('div');
    wrap.className = 'review-row';
    var dt = document.createElement('dt');
    dt.textContent = label;
    var dd = document.createElement('dd');
    dd.textContent = value;
    wrap.appendChild(dt);
    wrap.appendChild(dd);
    dl.appendChild(wrap);
  }

  function reviewCard(title) {
    var sec = document.createElement('section');
    sec.className = 'card';
    var h = document.createElement('h2');
    h.className = 'card-title';
    h.textContent = title;
    var dl = document.createElement('dl');
    dl.className = 'review-list';
    sec.appendChild(h);
    sec.appendChild(dl);
    els.reviewContent.appendChild(sec);
    return dl;
  }

  function renderReview(payload) {
    els.reviewContent.textContent = '';

    var basic = reviewCard('① 기본 정보');
    addRow(basic, '추천 부문', payload.categoryLabel);
    addRow(basic, '추천 유형', payload.nominationType === 'group'
      ? '단체 (' + payload.groupMembers.length + '명)' : '개인');

    if (payload.nominationType === 'individual') {
      var n = payload.nominee;
      addRow(basic, '추천 대상', n.name + ' / ' + n.org + ' / ' + n.rank);
    } else {
      var wrap = document.createElement('div');
      wrap.className = 'review-row';
      var dt = document.createElement('dt');
      dt.textContent = '구성원 명단';
      var dd = document.createElement('dd');
      var ol = document.createElement('ol');
      ol.className = 'review-members';
      payload.groupMembers.forEach(function (m) {
        var li = document.createElement('li');
        var strong = document.createElement('strong');
        strong.textContent = m.name;
        li.appendChild(strong);
        li.appendChild(document.createTextNode(' · ' + m.org + ' · ' + m.rank));
        var role = document.createElement('span');
        role.className = 'review-role';
        role.textContent = '역할: ' + m.role;
        li.appendChild(role);
        ol.appendChild(li);
      });
      dd.appendChild(ol);
      wrap.appendChild(dt);
      wrap.appendChild(dd);
      basic.appendChild(wrap);
    }

    var nom = payload.nominator;
    addRow(basic, '추천인', nom.name + ' / ' + nom.org + (nom.isSelfNomination ? ' (본인 추천)' : ''));
    addRow(basic, '관련 Winning Rules', payload.winningRule.number + '  ' + payload.winningRule.text);
    addRow(basic, '사례 기간', '2026년 ' + payload.casePeriod.startMonth + '월 ~ 2026년 ' + payload.casePeriod.endMonth + '월');

    var content = reviewCard('② 추천 내용');
    addRow(content, '무엇을 했나 (행동)', payload.content.action);
    addRow(content, '무엇이 달라졌나 (변화)', payload.content.change);
    addRow(content, '확인 근거', payload.content.evidence);

    var confirm = reviewCard('작성 확인');
    addRow(confirm, '사실 확인', '위 내용은 사실에 근거해 작성했습니다. ✓');
    addRow(confirm, '작성일', formatDate(new Date()));
  }

  function renderResult(result, payload) {
    var box = byId('result-box');
    var title = byId('result-title');
    var ref = byId('result-ref');
    var saved = result && result.saved === true && !!result.referenceId;

    box.className = 'result-box ' + (saved ? 'result-box--ok' : 'result-box--mock');
    if (saved) {
      title.textContent = '추천서 제출이 완료되었습니다';
      ref.textContent = '접수번호: ' + result.referenceId;
      ref.hidden = false;
    } else {
      title.textContent = '모의 제출 결과 (저장되지 않음)';
      ref.hidden = true;
    }
    byId('result-message').textContent = result.message;
    byId('payload-preview').textContent = JSON.stringify(payload, null, 2);
    // 실제로 저장된 경우에만 "작성 중" 상태를 해제합니다.
    if (saved) isDirty = false;
  }

  function resetForm() {
    els.form.reset();
    els.memberList.textContent = '';
    attempted = false;
    isDirty = false;
    currentState = null;
    clearErrors();
    els.errorSummary.hidden = true;
    updateTypeUI();
    updateCounters();
    updateSign();
    showView('form');
  }

  /* =========================================================
   * 6. 보조 기능: 글자 수 표시, 서명란
   * ========================================================= */
  function updateCounters() {
    ['content-action', 'content-change', 'content-evidence'].forEach(function (id) {
      var el = byId(id);
      byId(id + '-count').textContent = el.value.length + ' / ' + el.maxLength + '자';
    });
  }

  function updateSign() {
    var name = val('nominator-name').trim();
    var sign = byId('sign-name');
    sign.textContent = name || '추천인 성명을 입력하면 표시됩니다';
    sign.classList.toggle('muted', !name);
  }

  /* =========================================================
   * 7. 이벤트 연결
   * ========================================================= */
  function bindEvents() {
    els.form.addEventListener('change', function (e) {
      if (e.target.name === 'nominationType') updateTypeUI();
    });

    els.form.addEventListener('input', function (e) {
      isDirty = true;
      if (e.target.tagName === 'TEXTAREA') updateCounters();
      if (e.target.id === 'nominator-name') updateSign();
      if (e.target.id === 'rule-number') {
        e.target.value = e.target.value.replace(/\D/g, ''); // 숫자만 남기기
      }
      if (attempted) runValidation(false);
    });
    // select, checkbox 는 change 이벤트에서도 다시 검증
    els.form.addEventListener('change', function () {
      isDirty = true;
      if (attempted) runValidation(false);
    });

    els.addMember.addEventListener('click', function () {
      var row = addMember();
      isDirty = true;
      if (row) $('input', row).focus();
      if (attempted) runValidation(false);
    });

    els.memberList.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-action="remove"]');
      if (btn) removeMember(btn.closest('.member-row'));
    });

    els.form.addEventListener('submit', function (e) {
      e.preventDefault(); // 브라우저 기본 전송을 막습니다 (어디에도 보내지 않음)
      attempted = true;
      var r = runValidation(true);
      if (r.errors.length) {
        els.errorSummary.focus();
        els.errorSummary.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      currentState = r.state;
      renderReview(App.buildPayload(currentState));
      showView('review');
      byId('review-title').focus();
    });

    byId('reset-form').addEventListener('click', function () {
      if (!isDirty || window.confirm('작성 중인 내용이 모두 지워집니다. 처음부터 다시 작성할까요?')) {
        resetForm();
      }
    });

    byId('back-to-edit').addEventListener('click', function () { showView('form'); });
    byId('result-back').addEventListener('click', function () { showView('form'); });
    byId('pdf-btn').addEventListener('click', savePdf);
    byId('print-btn').addEventListener('click', savePdf);

    byId('new-form').addEventListener('click', function () {
      if (!isDirty || window.confirm('현재 내용은 저장되지 않았습니다. 지우고 새 추천서를 작성할까요?')) {
        resetForm();
      }
    });

    els.submitBtn.addEventListener('click', function () {
      if (submitting || !currentState) return;
      // 확인 화면에서 다시 한 번 검증 (안전장치)
      if (App.validate(currentState).length) { showView('form'); runValidation(true); return; }

      submitting = true;
      els.submitBtn.disabled = true;
      els.submitBtn.textContent = '처리 중…';
      var payload = App.buildPayload(currentState);

      App.submissionService.submit(payload).then(function (result) {
        renderResult(result, payload);
      }).catch(function (err) {
        renderResult({
          saved: false,
          referenceId: null,
          message: '제출하지 못했습니다. 추천서는 저장되지 않았습니다. (' + err.message + ')'
        }, payload);
      }).then(function () {
        submitting = false;
        els.submitBtn.disabled = false;
        setSubmitLabel();
        showView('result');
        byId('result-title').focus();
      });
    });

    // 입력 중에 창을 닫으려 하면 경고 (저장 기능이 없으므로 내용이 사라짐)
    window.addEventListener('beforeunload', function (e) {
      if (isDirty) { e.preventDefault(); e.returnValue = ''; }
    });
  }

  /*
   * PDF로 저장 — 브라우저의 인쇄 기능을 이용합니다.
   * 인쇄 창에서 'PDF로 저장'을 고르면 파일이 사용자 PC에만 저장됩니다. (외부 전송 없음)
   * 인쇄용 화면 모양은 style.css 의 @media print 부분에서 정합니다.
   */
  function savePdf() {
    if (!currentState) return;
    renderReview(App.buildPayload(currentState)); // 최신 내용으로 다시 그리기

    // 저장될 PDF 파일 이름은 페이지 제목(title)을 따라갑니다.
    var originalTitle = document.title;
    var p = App.buildPayload(currentState);
    var who = p.nominationType === 'group'
      ? (p.groupMembers[0] ? p.groupMembers[0].name + '외' + (p.groupMembers.length - 1) + '명' : '단체')
      : p.nominee.name;
    var cat = p.categoryLabel;
    document.title = ('가치실천시상_추천서_' + cat + '_' + who).replace(/[\\/:*?"<>|\s]+/g, '_');

    document.body.classList.add('print-nomination');
    window.print();
    document.body.classList.remove('print-nomination');
    document.title = originalTitle;
  }

  function setSubmitLabel() {
    var mock = App.submissionService.mode === 'mock';
    els.submitBtn.textContent = mock ? '모의 제출하기' : '제출하기';
    els.submitModeNote.textContent = mock
      ? '현재 모의 모드입니다. [모의 제출하기]를 눌러도 서버에 저장되거나 전송되지 않습니다.'
      : '제출 후에는 접수번호가 표시됩니다.';
  }

  /* =========================================================
   * 시작
   * ========================================================= */
  function init() {
    renderCategories();
    renderMonths(els.periodStart, '시작 월');
    renderMonths(els.periodEnd, '종료 월');
    applyLimits(document);
    renderDeadline();
    byId('write-date').textContent = formatDate(new Date());
    setSubmitLabel();
    updateTypeUI();
    updateCounters();
    bindEvents();
  }

  init();
})(window.AwardApp);
