/*
 * config.js — 화면과 규칙에 쓰이는 설정값을 한곳에 모아 둔 파일입니다.
 * 기간, 글자 수 제한, 부문 설명 등을 바꾸고 싶으면 이 파일만 수정하면 됩니다.
 * (출처: 상상인_2026연말가치실천시상_Pilot운영계획안.pdf)
 *
 * ⚠ 이 파일에는 비밀번호, API 키 같은 비밀 정보를 절대 넣지 마세요.
 *   브라우저로 내려가는 파일은 누구나 열어볼 수 있습니다.
 */
window.AwardApp = window.AwardApp || {};

window.AwardApp.config = {
  year: 2026,

  /*
   * 제출 방식
   *  - 'mock' : 모의 제출 (아무 데도 저장/전송하지 않음) ← 현재
   *  - 'api'  : 사내 승인 저장 서버로 전송 (서버가 준비된 뒤에만 사용)
   */
  submissionMode: 'mock',

  api: {
    // 사내 승인된 서버 주소가 정해지면 입력합니다. 예) '/api/nominations'
    // 이때 index.html 의 Content-Security-Policy(connect-src)도 함께 수정해야 합니다.
    endpoint: ''
  },

  // PDF 별첨 3 / 별첨 1 기준: "11.13(금)까지"
  // (참고: PDF 본문 04쪽 표는 추천 기간을 11/10~11/20으로 적고 있어 확인이 필요합니다.)
  deadline: '2026-11-13T23:59:59+09:00',
  deadlineLabel: '2026. 11. 13.(금)',

  // PDF 03쪽 "시상 부문과 심사 기준" (예시는 PDF의 가상 사례)
  categories: [
    {
      value: 'iroum',
      label: '이로움상',
      summary: '고객 · 사회에 만든 이로운 변화',
      example: '사회적 약자 지원, 공정한 문화 조성, 윤리적 의사결정 등으로 조직과 사회에 선한 영향을 준 사례'
    },
    {
      value: 'challenge',
      label: '도전상',
      summary: '새로운 시도 · 실험 · 학습',
      example: '관행을 바꾼 시도 후 실패를 분석하고 대안을 검증 · 공유함'
    },
    {
      value: 'connect',
      label: '연결상',
      summary: '조직 경계를 넘는 지식 · 경험 연결',
      example: '흩어진 경험을 모아 부서 간 공동 기준 · 협업 방식을 만듦'
    },
    {
      value: 'respect',
      label: '존중상',
      summary: '다른 관점 · 필요 반영',
      example: '현장 의견 · 소수 의견을 반영해 절차 · 접근성을 개선함'
    }
  ],

  nominationTypes: {
    individual: '개인',
    group: '단체'
  },

  // 입력 글자 수 제한 (필요하면 조정하세요)
  limits: {
    name: 30,
    org: 50,
    rank: 20,
    role: 100,
    ruleText: 150,
    action: 1500,
    change: 1500,
    evidence: 500
  },

  members: {
    min: 2,   // PDF: 단체는 2명 이상
    max: 50   // 화면 관리를 위한 상한 (PDF는 6명 이상은 별지 기재)
  }
};
