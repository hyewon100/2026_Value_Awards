/*
 * submission-service.js — "제출"을 담당하는 부분입니다.
 *
 * 화면(app.js)은 저장 방식이 무엇인지 모르고, 오직
 *   App.submissionService.submit(payload)
 * 만 호출합니다. 그래서 나중에 데이터베이스/서버를 연결할 때
 * 이 파일의 어댑터(adapter)만 바꾸면 화면 코드는 고치지 않아도 됩니다.
 *
 * 모든 어댑터는 아래 형태의 결과를 돌려줘야 합니다.
 *   {
 *     saved: true | false,     // 서버에 실제로 저장되었는가? (가장 중요)
 *     mode: 'mock' | 'api',
 *     referenceId: '접수번호' | null,  // 서버가 발급한 번호 (저장된 경우만)
 *     message: '사용자에게 보여줄 안내'
 *   }
 * 화면은 saved === true 이고 referenceId 가 있을 때만 "제출 완료"라고 표시합니다.
 */
(function (App) {
  'use strict';

  var cfg = App.config;

  /* ---------- 서버로 보낼 데이터(payload) 만들기 ---------- */
  // 화면 내부용 값(구성원 uid 등)을 빼고, DB에 저장하기 좋은 형태로 정리합니다.
  function buildPayload(state) {
    var category = cfg.categories.filter(function (c) { return c.value === state.category; })[0];
    var isGroup = state.nominationType === 'group';
    var t = function (v) { return (v || '').trim(); };

    return {
      schemaVersion: 1,
      program: '2026-year-end-value-award-pilot',
      category: state.category,
      categoryLabel: category ? category.label : '',
      nominationType: state.nominationType,
      nominee: isGroup ? null : {
        name: t(state.target.name),
        org: t(state.target.org),
        rank: t(state.target.rank)
      },
      groupMembers: isGroup ? state.members.map(function (m) {
        return { name: t(m.name), org: t(m.org), rank: t(m.rank), role: t(m.role) };
      }) : [],
      nominator: {
        name: t(state.nominator.name),
        org: t(state.nominator.org),
        isSelfNomination: !!state.nominator.isSelf
      },
      winningRule: {
        number: ('0' + t(state.winningRule.number)).slice(-2),
        text: t(state.winningRule.text)
      },
      casePeriod: {
        year: cfg.year,
        startMonth: state.period.startMonth,
        endMonth: state.period.endMonth
      },
      content: {
        action: t(state.content.action),
        change: t(state.content.change),
        evidence: t(state.content.evidence)
      },
      factConfirmed: state.factConfirmed === true,
      // 브라우저 시각은 참고용입니다. 실제 접수 시각은 서버가 기록해야 합니다.
      clientCreatedAt: new Date().toISOString()
    };
  }

  /* ---------- 어댑터 1: 모의 제출 (현재 사용) ---------- */
  // 아무 데도 저장하거나 전송하지 않습니다. 브라우저 저장소(localStorage)에도 남기지 않습니다.
  var mockAdapter = {
    mode: 'mock',
    submit: function (payload) {
      return new Promise(function (resolve) {
        setTimeout(function () {
          resolve({
            saved: false,
            mode: 'mock',
            referenceId: null,
            message: '모의 제출입니다. 추천서는 서버에 저장되지 않았고, 어디에도 전송되지 않았습니다.'
          });
        }, 500);
      });
    }
  };

  /* ---------- 어댑터 2: 사내 승인 서버 연결 (추후 사용) ---------- */
  // 사내 승인된 저장 환경이 준비되면 아래를 사용합니다.
  //  - 로그인/권한 확인은 서버(사내 SSO 등)가 담당합니다. 비밀번호·키를 이 파일에 넣지 마세요.
  //  - 서버는 저장에 성공했을 때만 접수번호(id)를 돌려주도록 만듭니다.
  var apiAdapter = {
    mode: 'api',
    submit: function (payload) {
      if (!cfg.api.endpoint) {
        return Promise.reject(new Error('서버 주소(config.api.endpoint)가 설정되지 않았습니다.'));
      }
      return fetch(cfg.api.endpoint, {
        method: 'POST',
        credentials: 'same-origin', // 사내 로그인 세션(쿠키) 사용
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).then(function (res) {
        if (!res.ok) throw new Error('서버 오류 (' + res.status + ')');
        return res.json();
      }).then(function (data) {
        var ok = !!(data && data.id);
        return {
          saved: ok,
          mode: 'api',
          referenceId: ok ? String(data.id) : null,
          message: ok ? '추천서가 정상적으로 접수되었습니다.'
                      : '서버 응답에 접수번호가 없어 저장 여부를 확인할 수 없습니다. 담당자에게 문의해 주세요.'
        };
      });
    }
  };

  var adapters = { mock: mockAdapter, api: apiAdapter };
  var active = adapters[cfg.submissionMode] || mockAdapter;

  App.buildPayload = buildPayload;
  App.submissionService = {
    mode: active.mode,
    submit: function (payload) { return active.submit(payload); }
  };
})(window.AwardApp);
